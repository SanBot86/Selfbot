# selfbot

1. apt update && apt upgrade ( Y )
2. pkg install python ( Y )
3. pkg install python3
4. pkg install git ( Y )
5. apt-get install youtube-dl
6. pip3 install thrift
7. pip3 install rsa
8. pip3 install requests
9. pip3 install thrift==0.11.0
10. pip3 install pytz
11. pip3 install pafy
12. pip install -U youtube-dl
13. pip3 install tweepy
14. pip3 install wikipedia
15. pip3 install googletrans
16. pip3 install ffmpy
